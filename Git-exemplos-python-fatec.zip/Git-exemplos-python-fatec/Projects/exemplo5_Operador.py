# Operações aritméeticas básicas 
a = 10 
b = 3
print("Valores:", a, "e", b) 
print("Adição:", a + b)
print("Subtração:", a - b) 
print("Multiplicação:", a * b) 
print("Divisão:", a / b) 
print("Divisão inteira:", a// b) 
print("Módulo e resto:", a % b) 
print("Exponenciação:", a **b)
