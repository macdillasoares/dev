# Estrutura if-else 
idade = 16 
if idade >= 18: 
    print("Vocêe é maior de idade!") 
    print("Direitos: votar, dirigir,trabalhar") 
else: 
    print("Você é menor de idade!") 
    print("Aguarde até completar 18 anos") 
# Exemplo prático:sistema de notas 
nota = 7.5 
if nota >= 6.0: 
    print(f"Aprovado com nota {nota}!") 
else:  
    print(f"Reprovado com nota{nota}.")
    print("Estude mais para a recuperação.")
