# Hello World personalizado 
nome = "Joãao" 
curso = "Segurança da Informação" 
faculdade = "Fatec Santana de Parnaíba"
print("Olá,", nome) 
print("Você está estudando",curso) 
print("na", faculdade) 
print("Bem-vindo ao mundo do Python!")
