# Hello World personalizado 
nome = "João" 
curso = "Segurança da Informação" 
faculdade = "Fatec Santana de Parnaíba"
print("Olá,", nome) 
print("Voceê está estudando",curso) 
print("na", faculdade) 
print("Bem-vindo ao mundo do Python!")

