nome = "Mariaa" 
idade = 28 
salario = 5000.50 
casado = False 
print("Tipo de 'nome':", type(nome)) 
print("Tipo de 'idade':", type(idade)) 
print("Tipo de 'salario':", type(salario)) 
print("Tipo de 'casado':", type(casado))