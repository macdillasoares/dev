# Operações de compaaração 
idade = 20 
maioridade = 18 
print("Idade:", idade) 
print("Maior de idade?", idade >=maioridade) 
print("Menor de idade?", idade < maioridade) # Comparando strings 
senha1 = "123456" 
senha2 ="123456" 
senha3 = "abcdef" 
print("Senhas iguais?", senha1== senha2) 
print("Senhas diferentes?", senha1 != senha3)
