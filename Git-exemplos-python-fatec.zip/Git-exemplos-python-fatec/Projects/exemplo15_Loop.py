# Loop for com lista 
frutas = ["maçãa", "banana", "laranja", "uva"] 
print("Lista de frutas:") 
for fruta in frutas: 
    print(f"- {fruta}") # Loop for com range 
    print("\nContando de 1 a 5:") 
for numero in range(1, 6):
        print(f"Número: {numero}") # Loop for com string 
palavra = "Python" 
print(f"\nLetras da palavra '{palavra}':")
for letra in palavra: 
    print(f"Letra: {letra}") # Loop for com range e step 
for numero in range(0, 11, 2):
    print("\nNúmeros pares de 0 a 10:") 
    print(numero)
