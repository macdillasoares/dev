# Estrutura if simples 
idade = 18 
if idade >= 18:
    print("Vocêe é maior de idade!") 
print("Pode votar e dirigir.") 
print("Este código sempre executa.") # Exemplo com diferentes idades 
idades = [15, 18, 25] 
for idade in idades: 
      print(f"\nTestando idade: {idade}") 
if idade >= 18:
    print("Maior de idade!")	
