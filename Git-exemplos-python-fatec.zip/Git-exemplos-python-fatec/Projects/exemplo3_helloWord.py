# Meu primeiro programa Python print("Hello World!") 
print("Oláa Mundo!") 
print("Bem-vindos à Fatec de Santana de Parnaíba!")
